using System.Collections.Generic;

namespace TodoApi.Util
{
    public class HotelListUtil
    {
        public static List<Hotel> hotels = new List<Hotel>();
    }
}